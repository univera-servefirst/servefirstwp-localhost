/* 
 * Inserts code to show the sticky icon for category-sticky plugin
 */


jQuery(document).ready(function($){
    $(".category-sticky .index-box .entry-header .category-list").before('<i class="fa fa-thumb-tack sticky-post"></i>');
});
